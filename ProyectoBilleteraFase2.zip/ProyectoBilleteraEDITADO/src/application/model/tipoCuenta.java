package application.model;

public enum tipoCuenta {

    AHORRO,
    CORRIENTE
}