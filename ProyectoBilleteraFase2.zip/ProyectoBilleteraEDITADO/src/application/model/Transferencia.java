package application.model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;

public class Transferencia extends Transaccion {

    public Transferencia(String idTransaccion, LocalDate fecha, double monto, String descripcion, String cuentaOrigen, String cuentaDestino) {
        super(idTransaccion, fecha, tipoTransaccion.TRANSFERENCIA, monto, descripcion, cuentaOrigen, cuentaDestino);
    }

    @Override
    public void verDetallesTransaccion() {
        System.out.println("Detalles de la Transferencia:");
        super.verDetallesTransaccion();
        System.out.println("Cuenta Origen: " + getCuentaOrigen());
        System.out.println("Cuenta Destino: " + getCuentaDestino());
    }

    @Override
    public String toString() {
        return "<Transferencia>@@<" + getIdTransaccion() + ">@@<" + getFecha() + ">@@<" + getMonto() + ">@@<" + getDescripcion() + ">@@<" + getCuentaOrigen() + ">@@<" + getCuentaDestino() + ">";
    }

    // Métodos de persistencia
    public static void guardarTransferenciaEnArchivo(Transferencia transferencia) throws IOException {
        String rutaArchivo = "C:\\td\\persistencia\\archivos\\transacciones.txt"; // Especifica la ruta completa del archivo

        File archivo = new File(rutaArchivo);

        // Si el archivo no existe, se creará
        if (!archivo.exists()) {
            archivo.createNewFile();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivo, true))) {
            writer.write(transferencia.toString()); // Usa el método toString para obtener el formato correcto
            writer.newLine();
        }
    }

    public static boolean transferenciaExiste(String idTransferencia, String idCuentaOrigen, String idCuentaDestino) throws IOException {
        String rutaArchivo = "C:\\td\\persistencia\\archivos\\transacciones.txt"; // Especifica la ruta completa del archivo

        // Leer el archivo y buscar si la transferencia ya existe
        try (BufferedReader reader = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] datosTransferencia = linea.split("@@");

                // Verificar si la línea tiene el número esperado de campos
                if (datosTransferencia.length < 7) { // Se espera un total de 7 elementos
                    System.err.println("Línea con formato incorrecto: " + linea); // Registro de error
                    continue; // Saltar la línea si no tiene el número esperado de campos
                }

                String idExistente = datosTransferencia[1].replaceAll("[<>]", ""); // Limpiar los caracteres < y >
                String idCO = datosTransferencia[5].replaceAll("[<>]", ""); // Limpiar los caracteres < y >
                String idCD = datosTransferencia[6].replaceAll("[<>]", ""); // Limpiar los caracteres < y >

                // Verificar si los datos coinciden
                if (idExistente.equals(idTransferencia) && idCO.equals(idCuentaOrigen) && idCD.equals(idCuentaDestino)) {
                    return true; // La transferencia ya existe
                }
            }
        }
        return false; // La transferencia no existe
    }

}
