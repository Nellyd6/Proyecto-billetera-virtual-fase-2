package application.model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;

public class Deposito extends Transaccion {

    // Constructor
    public Deposito(String idTransaccion, LocalDate fecha, double monto, String descripcion, String cuentaDestino) {
        super(idTransaccion, fecha, tipoTransaccion.DEPOSITO, monto, descripcion, null, cuentaDestino); // La cuenta origen es null para depósitos
    }

    @Override
    public void verDetallesTransaccion() {
        System.out.println("Detalles del Depósito:");
        System.out.println(super.toString()); // Llama a toString() de Transaccion
        System.out.println("Cuenta Destino: " + getCuentaDestino());
    }

    @Override
    public String toString() {
        return "<depósito>@@<" + getIdTransaccion() + ">@@<" + getFecha() + ">@@<" + getMonto() + ">@@<" + getDescripcion() + ">@@<" + getCuentaOrigen() + ">@@<" + getCuentaDestino() + ">";
    }

    public static void guardarDepositoEnArchivo(Deposito deposito) throws IOException {
        String rutaArchivo = "C:\\td\\persistencia\\archivos\\transacciones.txt"; // Especifica la ruta completa del archivo

        File archivo = new File(rutaArchivo);

        // Si el archivo no existe, se creará
        if (!archivo.exists()) {
            archivo.createNewFile();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivo, true))) {
            writer.write(deposito.toString()); // Usa el método toString para obtener el formato correcto
            writer.newLine();
        }
    }

    public static boolean depositoExiste(String idDeposito, String cuentaDestino) throws IOException {
        String rutaArchivo = "C:\\td\\persistencia\\archivos\\transacciones.txt"; // Especifica la ruta completa del archivo

        // Leer el archivo y buscar si el depósito ya existe
        try (BufferedReader reader = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] datosDeposito = linea.split("@@");

                // Verificar si la línea tiene el número esperado de campos
                if (datosDeposito.length < 7) { // Cambiado a 7
                    System.err.println("Línea con formato incorrecto: " + linea); // Registro de error
                    continue; // Saltar la línea si no tiene el número esperado de campos
                }

                String idExistente = datosDeposito[1].replaceAll("[<>]", ""); // Limpiar los caracteres < y >
                String cuentaD = datosDeposito[6].replaceAll("[<>]", ""); // Limpiar los caracteres < y >

                // Verificar si los datos coinciden
                if (idExistente.equals(idDeposito) && cuentaD.equals(cuentaDestino)) {
                    return true; // El depósito ya existe
                }
            }
        }
        return false; // El depósito no existe
    }
}
