package application.model;

public class Presupuesto {
    private int idPresupuesto;
    private String nombre;
    private double montoTotal;
    private double montoGastado;
    private Categoria categoria;

    // Constructor
    public Presupuesto(int idPresupuesto, String nombre, double montoTotal, Categoria categoria) {
        this.idPresupuesto = idPresupuesto;
        this.nombre = nombre;
        this.montoTotal = montoTotal;
        this.montoGastado = 0;
        this.categoria = categoria;
    }

    // Métodos
    public void crearPresupuesto() {
        System.out.println("Presupuesto creado: " + this.nombre + " con un monto de " + this.montoTotal);
    }

    public void actualizarPresupuesto(double nuevoMontoTotal) {
        this.montoTotal = nuevoMontoTotal;
        System.out.println("Presupuesto actualizado: " + this.nombre + " con un nuevo monto de " + this.montoTotal);
    }

    public void eliminarPresupuesto() {
        System.out.println("Presupuesto eliminado: " + this.nombre);
    }

    public void consultarEstado() {
        System.out.println("Presupuesto: " + this.nombre + " - Monto Total: " + this.montoTotal + " - Gastado: " + this.montoGastado);
    }

    public void registrarGasto(double gasto) {
        if (this.montoGastado + gasto <= this.montoTotal) {
            this.montoGastado += gasto;
            System.out.println("Gasto registrado. Gastado: " + this.montoGastado + " de " + this.montoTotal);
        } else {
            System.out.println("Gasto excede el presupuesto disponible.");
        }
    }

	public Object getIdPresupuesto() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setMontoGastado(double montoGastado2) {
		// TODO Auto-generated method stub
		
	}

	public int getMontoTotal() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

	public double getMontoGastado() {
		return montoGastado;
	}

	public void setIdPresupuesto(int idPresupuesto) {
		this.idPresupuesto = idPresupuesto;
	}

	public void setMontoTotal(double montoTotal) {
		this.montoTotal = montoTotal;
	}
}