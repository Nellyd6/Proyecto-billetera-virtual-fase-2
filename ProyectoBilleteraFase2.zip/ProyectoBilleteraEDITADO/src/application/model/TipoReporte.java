package application.model;

enum TipoReporte {
    INGRESOS, GASTOS, SALDO
}
