package application.model;

import java.io.Serializable;

public class FormatoEmailInvalidoException extends Exception implements Serializable {
	    private static final long serialVersionUID = 1L; // Agregar serialVersionUID

	    public FormatoEmailInvalidoException(String message) {
	        super(message);
	    }
	}


