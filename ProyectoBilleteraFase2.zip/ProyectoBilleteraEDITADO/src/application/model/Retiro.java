package application.model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;

public class Retiro extends Transaccion {

    // Constructor
    public Retiro(String idTransaccion, LocalDate fecha, double monto, String descripcion, String cuentaOrigen) {
        super(idTransaccion, fecha, tipoTransaccion.RETIRO, monto, descripcion, cuentaOrigen, null); // La cuenta destino es null para retiros
    }

    @Override
    public void verDetallesTransaccion() {
        System.out.println("Detalles del Retiro:");
        System.out.println(super.toString()); // Llama a toString() de Transaccion
        System.out.println("Cuenta Origen: " + getCuentaOrigen());
    }
    

    @Override
    public String toString() {
        return "<Retiro>@@<" + getIdTransaccion() + ">@@<" + getFecha() + ">@@<" + getMonto() + ">@@<" + getDescripcion() + ">@@<" + getCuentaOrigen() + ">@@<" + getCuentaDestino() + ">";
    }

    public static void guardarRetiroEnArchivo(Retiro retiro) throws IOException {
        String rutaArchivo = "C:\\td\\persistencia\\archivos\\transacciones.txt"; // Especifica la ruta completa del archivo

        File archivo = new File(rutaArchivo);

        // Si el archivo no existe, se creará
        if (!archivo.exists()) {
            archivo.createNewFile();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivo, true))) {
            writer.write(retiro.toString()); // Usa el método toString para obtener el formato correcto
            writer.newLine();
        }
    }

    public static boolean retiroExiste(String idRetiro, String cuentaOrigen) throws IOException {
        String rutaArchivo = "C:\\td\\persistencia\\archivos\\transacciones.txt"; // Especifica la ruta completa del archivo

        // Leer el archivo y buscar si el retiro ya existe
        try (BufferedReader reader = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] datosRetiro = linea.split("@@");

                // Verificar si la línea tiene el número esperado de campos
                if (datosRetiro.length < 6) { // Se espera un total de 6 elementos
                    System.err.println("Línea con formato incorrecto: " + linea); // Registro de error
                    continue; // Saltar la línea si no tiene el número esperado de campos
                }

                String idExistente = datosRetiro[1].replaceAll("[<>]", ""); // Limpiar los caracteres < y >
                String cuentaO = datosRetiro[5].replaceAll("[<>]", ""); // Limpiar los caracteres < y >

                // Verificar si los datos coinciden
                if (idExistente.equals(idRetiro) && cuentaO.equals(cuentaOrigen)) {
                    return true; // El retiro ya existe
                }
            }
        }
        return false; // El retiro no existe
    }
}
