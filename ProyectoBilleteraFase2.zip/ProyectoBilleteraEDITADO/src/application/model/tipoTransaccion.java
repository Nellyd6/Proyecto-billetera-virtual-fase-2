package application.model;

public enum tipoTransaccion {
    DEPOSITO,
    RETIRO,
    TRANSFERENCIA
}
