package application.model;

public interface OperacionDinero {
    void ejecutar() throws Exception;
}
