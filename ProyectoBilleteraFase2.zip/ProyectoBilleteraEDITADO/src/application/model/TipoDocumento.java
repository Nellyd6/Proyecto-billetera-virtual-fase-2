package application.model;


public enum TipoDocumento {
    TI,
    CEDULA;


	
}
