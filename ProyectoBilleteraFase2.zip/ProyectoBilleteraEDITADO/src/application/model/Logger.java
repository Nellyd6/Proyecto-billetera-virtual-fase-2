package application.model;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Logger {
	  private static final String LOG_FILE_PATH = "C:\\td\\persistencia\\log\\billeteraCashColombia_Log.txt";

	    // Método para registrar mensajes en el archivo de log
	    public static void log(String message) {
	        try (BufferedWriter writer = new BufferedWriter(new FileWriter(LOG_FILE_PATH, true))) {
	            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
	            writer.write("[" + timestamp + "] " + message);
	            writer.newLine();
	        } catch (IOException e) {
	            System.err.println("Error al escribir en el archivo de log: " + e.getMessage());
	        }
	    }

}
