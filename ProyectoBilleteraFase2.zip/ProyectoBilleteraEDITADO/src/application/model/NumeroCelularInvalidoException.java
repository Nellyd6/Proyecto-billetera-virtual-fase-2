package application.model;

import java.io.Serializable;

public class NumeroCelularInvalidoException extends Exception implements Serializable {
    private static final long serialVersionUID = 1L; 

    public NumeroCelularInvalidoException(String message) {
        super(message);
    }
}
