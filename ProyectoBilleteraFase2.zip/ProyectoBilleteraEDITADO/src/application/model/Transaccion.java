package application.model;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Date;

public class Transaccion {
    private String idTransaccion;
    private LocalDate fecha;
    private tipoTransaccion tipo; // Depósito, Retiro, Transferencia
    private double monto;
    private String descripcion;
    private String cuentaOrigen;
    private String cuentaDestino;

    // Constructor
    public Transaccion(String idTransaccion, LocalDate fecha, tipoTransaccion tipo, double monto, String descripcion, String cuentaOrigen, String cuentaDestino) {
        this.idTransaccion = idTransaccion;
        this.fecha = fecha;
        this.tipo = tipo;
        this.monto = monto;
        this.descripcion = descripcion;
        this.cuentaOrigen = cuentaOrigen;
        this.cuentaDestino = cuentaDestino;
    }

    // Métodos
    public void crearTransaccion() {
        System.out.println("Transacción creada: " + this.tipo + " por " + this.monto);
        if (cuentaOrigen != null) {
            System.out.println("Cuenta Origen: " + cuentaOrigen);
        }
        if (cuentaDestino != null) {
            System.out.println("Cuenta Destino: " + cuentaDestino);
        }
    }

    public void listarTransacciones() {
        // Aquí iría la lógica para listar todas las transacciones
        System.out.println("Transacción: " + this.descripcion + " de " + this.monto);
    }

    public void verDetallesTransaccion() {
        System.out.println("Detalles de la Transacción: ID " + idTransaccion + " - Tipo: " + tipo + " - Monto: " + monto + " - Fecha: " + fecha);
        System.out.println("Descripción: " + descripcion);
        if (cuentaOrigen != null) {
            System.out.println("Cuenta Origen: " + cuentaOrigen);
        }
        if (cuentaDestino != null) {
            System.out.println("Cuenta Destino: " + cuentaDestino);
        }
    }

    @Override
    public String toString() {
        return "Transacción: " + tipo + " - Monto: " + monto + " - Fecha: " + fecha + " - Descripción: " + descripcion;
    }

	public LocalDate getFecha() {
		// TODO Auto-generated method stub
		return fecha;
	}

	public String getIdTransaccion() {
		return idTransaccion;
	}

	public void setIdTransaccion(String idTransaccion) {
		this.idTransaccion = idTransaccion;
	}

	public tipoTransaccion getTipo() {
		return tipo;
	}

	public void setTipo(tipoTransaccion tipo) {
		this.tipo = tipo;
	}

	public double getMonto() {
		return monto;
	}

	public void setMonto(double monto) {
		this.monto = monto;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getCuentaOrigen() {
		return cuentaOrigen;
	}

	public void setCuentaOrigen(String cuentaOrigen) {
		this.cuentaOrigen = cuentaOrigen;
	}

	public String getCuentaDestino() {
		return cuentaDestino;
	}

	public void setCuentaDestino(String cuentaDestino) {
		this.cuentaDestino = cuentaDestino;
	}



	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	
	
	// Métodos de persistencia
    
	 
   
	
	
	
	
}
