package application.model;


public class CuentaNoValidaException extends Exception {
 
	private static final long serialVersionUID = 1L;

 public CuentaNoValidaException(String message) {
     super(message);
 }
}
