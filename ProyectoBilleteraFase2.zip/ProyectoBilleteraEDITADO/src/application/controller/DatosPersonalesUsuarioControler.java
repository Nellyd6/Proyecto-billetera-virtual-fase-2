package application.controller;

import java.net.URL;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import application.model.Usuario;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class DatosPersonalesUsuarioControler {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextArea areaCelular;

    @FXML
    private TextArea areaDireccion;

    @FXML
    private TextArea areaEmail;

    @FXML
    private TextArea areaNombre;

    @FXML
    private TextArea areaTipoDocumento;

    @FXML
    private TextArea areaId;

    @FXML
    private Button botonActualizarDatos;
    
    @FXML
    private Button botonVolverventana;

    // Variable para controlar si los campos son editables
    private boolean editables = false;

    // Método para cargar los datos del usuario
    public void cargarDatosUsuario(Usuario usuario) {
        areaTipoDocumento.setText(usuario.getTipoDocumento().toString());
        areaId.setText(usuario.getIdUsuario());
        areaNombre.setText(usuario.getNombre());
        areaCelular.setText(usuario.getCelular());
        areaEmail.setText(usuario.getCorreo());
        areaDireccion.setText(usuario.getDireccion());

        // Al inicio, los campos no son editables
        setCamposEditables(false);
    }

    @FXML
    void actualizarPerfil(ActionEvent event) {
        if (editables) {
            // Guardar los cambios y deshabilitar la edición
            String tipoDocumento = areaTipoDocumento.getText();
            String id = areaId.getText();
            String nombreCompleto = areaNombre.getText();
            String celular = areaCelular.getText();
            String correo = areaEmail.getText();
            String direccion = areaDireccion.getText();

            // Validar si algún campo está vacío
            if (tipoDocumento == null || id.isEmpty() || nombreCompleto.isEmpty() || celular.isEmpty() || correo.isEmpty() || direccion.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos.");
                return;
            }

            // Después de guardar los cambios, deshabilitar la edición
            setCamposEditables(false);
            editables = false;
            botonActualizarDatos.setText("Actualizar datos");

        } else {
            // Habilitar la edición de los campos
            setCamposEditables(true);
            editables = true;
            botonActualizarDatos.setText("Guardar cambios");
        }
    }

    // Método para habilitar o deshabilitar la edición de los campos
    private void setCamposEditables(boolean editable) {
        areaNombre.setEditable(editable);
        areaCelular.setEditable(editable);
        areaEmail.setEditable(editable);
        areaDireccion.setEditable(editable);
    }
    
    @FXML
    void volverVentanaAnterior(ActionEvent event) {
    	 try {
             // Cargar la vista de la billetera
             Parent root = FXMLLoader.load(getClass().getResource("/application/viewCuentaUsuario.fxml"));
             Scene scene = new Scene(root);
             scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());

             // Mostrar la nueva ventana
             Stage nuevaVentana = new Stage();
             nuevaVentana.setTitle("");
             nuevaVentana.setScene(scene);
             nuevaVentana.show();

             // Ocultar la ventana actual
             Stage stageActual = (Stage) ((Node) event.getSource()).getScene().getWindow();
             stageActual.close();
         } catch (Exception e) {
             e.printStackTrace();
         }
    }
    

    @FXML
    void initialize() {
        // Inicialización si es necesario
    }
}
