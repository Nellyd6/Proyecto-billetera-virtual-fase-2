package application.controller;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import application.model.Logger;
import application.model.Transferencia;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class TransferenciaController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button botonGuardarTransferencia;

    @FXML
    private Button botonVolverTransferencia;

    @FXML
    private TextField cuentaDestinoTransferencia;

    @FXML
    private TextField cuentaOrigenTransferencia;

    @FXML
    private TextField descripcionTransferencia;

    @FXML
    private DatePicker fechaTransferencia;

    @FXML
    private TextField idTransferencia;

    @FXML
    private TextField montoTransferencia;

    @FXML
    void guardarTransaferenciaUsuario(ActionEvent event) {
        // Obtener los valores de los campos
        String idTransfer = idTransferencia.getText();
        LocalDate fecha = fechaTransferencia.getValue();
        String montoText = montoTransferencia.getText();
        String cO = cuentaOrigenTransferencia.getText();
        String cD = cuentaDestinoTransferencia.getText();
        String descrip = descripcionTransferencia.getText();

        // Validar si algún campo está vacío
        if (idTransfer.isEmpty() || fecha == null || montoText.isEmpty() || cO.isEmpty() || cD.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos.");
            Logger.log("Intento de transacción fallida: Campos incompletos.");
            return;
        }

        try {
            double monto = Double.parseDouble(montoText); // Parsear el monto aquí

            // Verificar si la transferencia ya existe en el archivo
            if (Transferencia.transferenciaExiste(idTransfer, cO, cD)) {
                Logger.log("Transferencia fallida: La transferencia ya se encuentra registrada con ID: " + idTransfer);
                JOptionPane.showMessageDialog(null, "La transferencia ya se encuentra registrada.");
            } else {
                // Crear un nuevo objeto Transferencia y guardarlo
                Transferencia nuevaTransferencia = new Transferencia(idTransfer, fecha, monto, descrip, cO, cD);
                Transferencia.guardarTransferenciaEnArchivo(nuevaTransferencia);

                JOptionPane.showMessageDialog(null, "Transferencia registrada con éxito.");
            }
        } catch (IOException e) {
            Logger.log("Error al acceder al archivo: " + e.getMessage());
            System.out.println("Ocurrió un error al acceder al archivo: " + e.getMessage());
        } catch (NumberFormatException e) {
            Logger.log("Error en el formato del monto: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "El monto ingresado no es válido. Por favor, intente de nuevo.");
        }

        // Limpiar los campos después del registro
        idTransferencia.clear();
        cuentaOrigenTransferencia.clear();
        cuentaDestinoTransferencia.clear();
        descripcionTransferencia.clear();
        fechaTransferencia.setValue(null);
        montoTransferencia.clear();
    }

    @FXML
    void volvertranferenciausuario(ActionEvent event) {
        try {
            // Cargar la vista de la billetera
            Parent root = FXMLLoader.load(getClass().getResource("/application/viewCuentaUsuario.fxml"));
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());

            // Mostrar la nueva ventana
            Stage nuevaVentana = new Stage();
            nuevaVentana.setTitle("Cuenta Usuario");
            nuevaVentana.setScene(scene);
            nuevaVentana.show();

            // Ocultar la ventana actual
            Stage stageActual = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stageActual.hide();
        } catch (Exception e) {
            Logger.log("Error al volver a la ventana de la cuenta del usuario: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    void initialize() {
        assert botonGuardarTransferencia != null : "fx:id=\"botonGuardarTransferencia\" was not injected: check your FXML file 'viewTransferencia.fxml'.";
        assert botonVolverTransferencia != null : "fx:id=\"botonVolverTransferencia\" was not injected: check your FXML file 'viewTransferencia.fxml'.";
        assert cuentaDestinoTransferencia != null : "fx:id=\"cuentaDestinoTransferencia\" was not injected: check your FXML file 'viewTransferencia.fxml'.";
        assert cuentaOrigenTransferencia != null : "fx:id=\"cuentaOrigenTransferencia\" was not injected: check your FXML file 'viewTransferencia.fxml'.";
        assert descripcionTransferencia != null : "fx:id=\"descripcionTransferencia\" was not injected: check your FXML file 'viewTransferencia.fxml'.";
        assert fechaTransferencia != null : "fx:id=\"fechaTransferencia\" was not injected: check your FXML file 'viewTransferencia.fxml'.";
        assert idTransferencia != null : "fx:id=\"idTransferencia\" was not injected: check your FXML file 'viewTransferencia.fxml'.";
        assert montoTransferencia != null : "fx:id=\"montoTransferencia\" was not injected: check your FXML file 'viewTransferencia.fxml'.";
    }
}
