package application.controller;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import application.model.Deposito;
import application.model.Logger;
import application.model.Retiro;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class RetiroController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField descripcionRetiro;

    @FXML
    private DatePicker fechaRetiro;

    @FXML
    private Button guardadRetiro;

    @FXML
    private TextField idCuentaRetiro;

    @FXML
    private TextField idRetiro;

    @FXML
    private TextField montoRetiro;

    @FXML
    private Button volverDelRetiro;

    @FXML
    void guerdarRetiroUsuario(ActionEvent event) {
    	
    	// Obtener los valores de los campos
    	String idRetir = idRetiro.getText();
        LocalDate fecha = fechaRetiro.getValue();
        String montoText = montoRetiro.getText();
        String cuenta = idCuentaRetiro.getText();
        String descrip = descripcionRetiro.getText();

        // Validar si algún campo está vacío
        if (idRetir.isEmpty() || fecha == null || montoText.isEmpty() || cuenta.isEmpty() || descrip.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos.");
            Logger.log("Intento de retiro fallido: Campos incompletos.");
            return;
        }

        double monto = 0;
        try {
            monto = Double.parseDouble(montoText); // Parsear el monto aquí
        } catch (NumberFormatException e) {
            Logger.log("Error en el formato del monto: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "El monto ingresado no es válido. Por favor, intente de nuevo.");
            return; // Salir del método si el monto no es válido
        }

        try {
            // Verificar si el retiro ya existe en el archivo
            if (Retiro.retiroExiste(idRetir, cuenta)) {
                Logger.log("Retiro fallido: El retiro ya se encuentra registrado con ID: " + idRetir);
                JOptionPane.showMessageDialog(null, "El retiro ya se encuentra registrado.");
            } else {
                // Crear un nuevo objeto retiro y guardarlo
                Retiro nuevoRetiro = new Retiro(idRetir, fecha, monto, descrip, cuenta);
                Retiro.guardarRetiroEnArchivo(nuevoRetiro);
                JOptionPane.showMessageDialog(null, "Retiro registrado con éxito.");
            }
        } catch (IOException e) {
            Logger.log("Error al acceder al archivo: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Ocurrió un error al acceder al archivo: " + e.getMessage());
        }

        // Limpiar los campos después del registro
        idRetiro.clear();
        fechaRetiro.setValue(null);
        montoRetiro.clear();
        idCuentaRetiro.clear();
        descripcionRetiro.clear();

    }

    @FXML
    void volverDelRetiroUsuario(ActionEvent event) {
    	
    	try {
            // Cargar la vista de la billetera
            Parent root = FXMLLoader.load(getClass().getResource("/application/viewCuentaUsuario.fxml"));
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());

            // Mostrar la nueva ventana
            Stage nuevaVentana = new Stage();
            nuevaVentana.setTitle("CuentaUsuario");
            nuevaVentana.setScene(scene);
            nuevaVentana.show();

            // Ocultar la ventana actual
            Stage stageActual = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stageActual.hide();
        } catch (Exception e) {
        	Logger.log("Error al volver a la ventana de la cuenta del usuario: " + e.getMessage());
            e.printStackTrace();
        }

    }

    @FXML
    void initialize() {
        assert descripcionRetiro != null : "fx:id=\"descripcionRetiro\" was not injected: check your FXML file 'viewRetiro.fxml'.";
        assert fechaRetiro != null : "fx:id=\"fechaRetiro\" was not injected: check your FXML file 'viewRetiro.fxml'.";
        assert guardadRetiro != null : "fx:id=\"guardadRetiro\" was not injected: check your FXML file 'viewRetiro.fxml'.";
        assert idCuentaRetiro != null : "fx:id=\"idCuentaRetiro\" was not injected: check your FXML file 'viewRetiro.fxml'.";
        assert idRetiro != null : "fx:id=\"idRetiro\" was not injected: check your FXML file 'viewRetiro.fxml'.";
        assert montoRetiro != null : "fx:id=\"montoRetiro\" was not injected: check your FXML file 'viewRetiro.fxml'.";
        assert volverDelRetiro != null : "fx:id=\"volverDelRetiro\" was not injected: check your FXML file 'viewRetiro.fxml'.";

    }

}
