package application.controller;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import application.model.Deposito;
import application.model.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class DepositoController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private DatePicker FechaDeposito;

    @FXML
    private Button botonGuardarDeposito;

    @FXML
    private Button botonVolverDeposito;

    @FXML
    private TextField descripcionDeposito;

    @FXML
    private TextField idCuentaDeposito;

    @FXML
    private TextField idDeposito;

    @FXML
    private TextField montoDeposito;

    @FXML
    void guardarDepositioUsuario(ActionEvent event) {
        // Obtener los valores de los campos
        String idDepos = idDeposito.getText();
        LocalDate fecha = FechaDeposito.getValue();
        String montoText = montoDeposito.getText();
        String cD = idCuentaDeposito.getText();
        String descrip = descripcionDeposito.getText();

        // Validar si algún campo está vacío
        if (idDepos.isEmpty() || fecha == null || montoText.isEmpty() || cD.isEmpty() || descrip.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos.");
            Logger.log("Intento de depósito fallido: Campos incompletos.");
            return;
        }

        double monto = 0;
        try {
            monto = Double.parseDouble(montoText); // Parsear el monto aquí
        } catch (NumberFormatException e) {
            Logger.log("Error en el formato del monto: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "El monto ingresado no es válido. Por favor, intente de nuevo.");
            return; // Salir del método si el monto no es válido
        }

        try {
            // Verificar si el depósito ya existe en el archivo
            if (Deposito.depositoExiste(idDepos, cD)) {
                Logger.log("Depósito fallido: El depósito ya se encuentra registrado con ID: " + idDepos);
                JOptionPane.showMessageDialog(null, "El depósito ya se encuentra registrado.");
            } else {
                // Crear un nuevo objeto Depósito y guardarlo
                Deposito nuevoDeposito = new Deposito(idDepos, fecha, monto, descrip, cD);
                Deposito.guardarDepositoEnArchivo(nuevoDeposito);
                JOptionPane.showMessageDialog(null, "Depósito registrado con éxito.");
            }
        } catch (IOException e) {
            Logger.log("Error al acceder al archivo: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Ocurrió un error al acceder al archivo: " + e.getMessage());
        }

        // Limpiar los campos después del registro
        idDeposito.clear();
        FechaDeposito.setValue(null);
        montoDeposito.clear();
        idCuentaDeposito.clear();
        descripcionDeposito.clear();
    }

    @FXML
    void volverDelDeposito(ActionEvent event) {
        try {
            // Cargar la vista de la billetera
            Parent root = FXMLLoader.load(getClass().getResource("/application/viewCuentaUsuario.fxml"));
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());

            // Mostrar la nueva ventana
            Stage nuevaVentana = new Stage();
            nuevaVentana.setTitle("CuentaUsuario");
            nuevaVentana.setScene(scene);
            nuevaVentana.show();

            // Ocultar la ventana actual
            Stage stageActual = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stageActual.hide();
        } catch (Exception e) {
            Logger.log("Error al volver a la ventana de la cuenta del usuario: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    void initialize() {
        assert FechaDeposito != null : "fx:id=\"FechaDeposito\" was not injected: check your FXML file 'viewDeposito.fxml'.";
        assert botonGuardarDeposito != null : "fx:id=\"botonGuardarDeposito\" was not injected: check your FXML file 'viewDeposito.fxml'.";
        assert botonVolverDeposito != null : "fx:id=\"botonVolverDeposito\" was not injected: check your FXML file 'viewDeposito.fxml'.";
        assert descripcionDeposito != null : "fx:id=\"descripcionDeposito\" was not injected: check your FXML file 'viewDeposito.fxml'.";
        assert idCuentaDeposito != null : "fx:id=\"idCuentaDeposito\" was not injected: check your FXML file 'viewDeposito.fxml'.";
        assert idDeposito != null : "fx:id=\"idDeposito\" was not injected: check your FXML file 'viewDeposito.fxml'.";
        assert montoDeposito != null : "fx:id=\"montoDeposito\" was not injected: check your FXML file 'viewDeposito.fxml'."; // Corregido
    }
}

