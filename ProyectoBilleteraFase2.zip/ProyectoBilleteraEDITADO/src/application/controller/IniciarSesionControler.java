package application.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import application.model.Logger;
import application.model.TipoDocumento;
import application.model.Usuario;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class IniciarSesionControler {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button botonIngresar;

    @FXML
    private Button botonVolverBilletera;

    @FXML
    private ComboBox<TipoDocumento> boxTipoDocumento2;

    @FXML
    private TextField textId;

    @FXML
    void agregarDocumento(ActionEvent event) {
        
    }

    @FXML
    void agregarId(ActionEvent event) {
       
    }

    @FXML
    void iniciarSesion(ActionEvent event) {
        // Obtener el tipo de documento seleccionado y el ID ingresado
        TipoDocumento tipoDocumento2 = boxTipoDocumento2.getValue();
        String id = textId.getText();

        // Validar si algún campo está vacío
        if (tipoDocumento2 == null || id.isEmpty()) {
            mostrarAlerta("Campos incompletos", "Por favor, complete todos los campos.");
            Logger.log("Intento de inicio de sesión fallido: Campos incompletos.");
            return;
        }

        try {
            // Verificar si el usuario ya existe en el archivo
            if (Usuario.validarUsuarioCreado(tipoDocumento2, Integer.parseInt(id))) {
            	Logger.log("Inicio de sesión exitoso para el usuario con ID: " + id);
                JOptionPane.showMessageDialog(null, " Sesión iniciada correctamente");

               
                Parent root = FXMLLoader.load(getClass().getResource("/application/viewCuentaUsuario.fxml"));
                Scene scene = new Scene(root);
                scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
                Stage nuevaVentana = new Stage();
                nuevaVentana.setTitle("Cuenta de Usuario");
                nuevaVentana.setScene(scene);
                nuevaVentana.show();

                // Ocultar la ventana actual
                Stage stageActual = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stageActual.hide();
                
            } else {
                // Si el usuario no está registrado, mostrar el diálogo con dos opciones
                int opcion = JOptionPane.showOptionDialog(
                        null, 
                        "El número de documento no está registrado. ¿Desea registrarse?", 
                        "Usuario no encontrado", 
                        JOptionPane.YES_NO_OPTION, 
                        JOptionPane.QUESTION_MESSAGE, 
                        null, 
                        new Object[] { "Registrar", "Cancelar" }, 
                        "Registrar");

                if (opcion == JOptionPane.YES_OPTION) {
                    // Redirigir a la ventana de registro si se selecciona "Registrar"
                    mostrarVentanaRegistro(event);
                } else {
                    // Cancelar la operación
                    JOptionPane.showMessageDialog(null, "Operación cancelada.");
                }
            }

        } catch (IOException e) {
        	Logger.log("Error al acceder al archivo: " + e.getMessage());
            System.out.println("Ocurrió un error al acceder al archivo: " + e.getMessage());
        } catch (NumberFormatException e) {
        	 Logger.log("Error en el formato del ID: " + e.getMessage());
        	 JOptionPane.showMessageDialog(null,"Error en el formato del ID: " + e.getMessage());
        }
    }

    // Método para mostrar la ventana de registro
    private void mostrarVentanaRegistro(ActionEvent event) {
        try {
        	Parent root = FXMLLoader.load(getClass().getResource("/application/viewRegistroUsuario.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage nuevaVentana = new Stage();
			nuevaVentana.setTitle("CashColombia");
			nuevaVentana.setScene(scene);
			nuevaVentana.show();
		 
			// Ocultar la ventana actual
			Stage stageActual = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stageActual.hide();
		} catch(Exception e) {
			Logger.log("Error al mostrar la ventana de registro: " + e.getMessage());
            
			e.printStackTrace();
		}
    }

    @FXML
    void volverVentanaBilletera(ActionEvent event) {
        try {
            // Cargar la vista de la billetera
            Parent root = FXMLLoader.load(getClass().getResource("/application/viewBilletera.fxml"));
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());

            // Mostrar la nueva ventana
            Stage nuevaVentana = new Stage();
            nuevaVentana.setTitle("CashColombia");
            nuevaVentana.setScene(scene);
            nuevaVentana.show();

            // Ocultar la ventana actual
            Stage stageActual = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stageActual.hide();
        } catch (Exception e) {
        	Logger.log("Error al volver a la ventana de billetera: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    void initialize() {
        // Agregar los valores de TipoDocumento al ComboBox
        boxTipoDocumento2.getItems().addAll(TipoDocumento.values());

        // Validación para que solo se puedan ingresar números en el campo ID
        textId.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                if (!newValue.matches("\\d*")) {
                    textId.setText(newValue.replaceAll("[^\\d]", ""));
                }
            }
        });
    }

    // Método para mostrar alertas de JavaFX
    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
  }

