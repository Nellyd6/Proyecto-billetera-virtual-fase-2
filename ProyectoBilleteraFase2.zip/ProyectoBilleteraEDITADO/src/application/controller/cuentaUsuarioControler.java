package application.controller;

import javafx.event.ActionEvent;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;



public class cuentaUsuarioControler {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;
    
    @FXML
    private TextArea areaNombreUsuario;

    @FXML
    private TextArea areaSaldoActual;
    
     @FXML
    private ImageView imagenU;

  

    @FXML
    private Button botonCategorias;

    @FXML
    private Button botonCuentasUsuarios;

    @FXML
    private Button botonDepositarPlata;

    @FXML
    private Button botonEnviarPlata;

    @FXML
    private Button botonMovimientos;

    @FXML
    private Button botonRetirarPlata;

    @FXML
    private AnchorPane textSaldoActual;
    
    @FXML
    void enviarTransferencia(ActionEvent event) {
    	
    	try {
			Parent root = FXMLLoader.load(getClass().getResource("/application/viewTransferencia.fxml"));
			
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage nuevaVentana= new Stage();
			nuevaVentana.setTitle("Transferencia");
			nuevaVentana.setScene(scene);
			nuevaVentana.show();
		 
			
			Stage stageActual = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stageActual.hide();
		} catch(Exception e) {
			e.printStackTrace();
		}
    	

    }
    

    @FXML
    void mostrarDatosPersonales(MouseEvent event) {
    	
    	try {
			Parent root = FXMLLoader.load(getClass().getResource("/application/viewDatosPersonales.fxml"));
			
			
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage nuevaVentana= new Stage();
			nuevaVentana.setTitle("Perfil");
			nuevaVentana.setScene(scene);
			nuevaVentana.show();
		 
			
			Stage stageActual = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stageActual.hide();
		} catch(Exception e) {
			e.printStackTrace();
		}
    	
    	

    }
    @FXML
    void mostrarInformacionDatos(MouseEvent event) {

    }
    
    @FXML
    void realizarDeposito(ActionEvent event) {
    	
    	try {
			Parent root = FXMLLoader.load(getClass().getResource("/application/viewDeposito.fxml"));
			
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage nuevaVentana= new Stage();
			nuevaVentana.setTitle("Deposito");
			nuevaVentana.setScene(scene);
			nuevaVentana.show();
		 
			
			Stage stageActual = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stageActual.hide();
		} catch(Exception e) {
			e.printStackTrace();
		}

    }

    @FXML
    void realizarRetiro(ActionEvent event) {
    	
    	try {
			Parent root = FXMLLoader.load(getClass().getResource("/application/viewRetiro.fxml"));
			
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage nuevaVentana= new Stage();
			nuevaVentana.setTitle("Retiro");
			nuevaVentana.setScene(scene);
			nuevaVentana.show();
		 
			
			Stage stageActual = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stageActual.hide();
		} catch(Exception e) {
			e.printStackTrace();
		}

    }

    @FXML
    void initialize() {
     
    }

}
